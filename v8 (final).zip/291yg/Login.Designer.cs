﻿namespace _291yg
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customer_login = new System.Windows.Forms.Button();
            this.employee_login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // customer_login
            // 
            this.customer_login.Location = new System.Drawing.Point(159, 56);
            this.customer_login.Name = "customer_login";
            this.customer_login.Size = new System.Drawing.Size(411, 120);
            this.customer_login.TabIndex = 0;
            this.customer_login.Text = "Customer Login";
            this.customer_login.UseVisualStyleBackColor = true;
            this.customer_login.Click += new System.EventHandler(this.button1_Click);
            // 
            // employee_login
            // 
            this.employee_login.Location = new System.Drawing.Point(159, 232);
            this.employee_login.Name = "employee_login";
            this.employee_login.Size = new System.Drawing.Size(415, 130);
            this.employee_login.TabIndex = 1;
            this.employee_login.Text = "Employee Login";
            this.employee_login.UseVisualStyleBackColor = true;
            this.employee_login.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.employee_login);
            this.Controls.Add(this.customer_login);
            this.Name = "Form1";
            this.Text = "Car Rental 2022";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button customer_login;
        private Button employee_login;
    }
}