namespace _291yg
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EmployeeLogin EL = new EmployeeLogin();
                EL.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            CustomerLogin F3 = new CustomerLogin();
                F3.Show();
            this.Hide();

        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}