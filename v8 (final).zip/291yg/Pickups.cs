﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _291yg
{

    public partial class Pickups : Form
    {
        public SqlConnection myConnection;
        public SqlCommand myCommand;
        public SqlDataReader myReader;

        public String CID;
        public String EID;
        public String gold;
        public Pickups(String A, String B)
        {
            InitializeComponent();

            CID = A;
            EID = B;
            label19.Text = A;
            label18.Text = B;

            String connectionString = "Server = DESKTOP-A7CNV87; Database = projects22g6; Trusted_Connection = yes;";

            SqlConnection myConnection = new SqlConnection(connectionString); // Timeout in seconds

            try
            {
                myConnection.Open(); // Open connection
                myCommand = new SqlCommand();
                myCommand.Connection = myConnection; // Link the command stream to the connection
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error");
                this.Close();
            }

            try
            {
                myCommand.CommandText = "select gold_star_status from customer where customer_ID = " + CID;
                myReader = myCommand.ExecuteReader();

                myReader.Read();
                gold = myReader["gold_star_status"].ToString();
                myReader.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Error");
                this.Close();
            }

            if (gold != "1")
            { 
                label20.Visible = false;
                comboBox2.Visible = false;
                button4.Visible = false;
            }


        }

        private void carinv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string type_id = "";

            if (comboBox1.Text == "Sedan")

            { type_id = "1";
            }

            if (comboBox1.Text == "SUV")

            {
                type_id = "2";
            }
            if (comboBox1.Text == "Van")

            {
                type_id = "3";
            }
            if (comboBox1.Text == "Truck")

            {
                type_id = "4";
            }
            if (comboBox1.Text == "Luxury Sedan")

            {
                type_id = "5";
            }
            if (comboBox1.Text == "Luxury SUV")

            {
                type_id = "6";
            }







            if (comboBox3.Text == "North Alberta")
            {
                if (type_id != "")
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'North Alberta' and T.typeid = " + type_id; }

                else
                        { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'North Alberta'"; }

                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }

            if (comboBox3.Text == "South Alberta")
            {
                if (type_id != "")
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'South Alberta' and T.typeid = " + type_id; }

                else
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'South Alberta'"; }


                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }

            if (comboBox3.Text == "West BC")
            {
                if (type_id != "")
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'West BC' and T.typeid = " + type_id; }

                else
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'West BC'"; }

                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }

            if (comboBox3.Text == "" | comboBox3.Text == "All")
            {
                if (type_id != "")
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and T.typeid = " + type_id; }

                else
                { myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid"; }

                /*if (operation.Text == "Show with starting grade: ")
                    myCommand.CommandText += " where grade >= " + SmallestGrade.Text;*/

                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int months = 0;
            int weeks = 0;

            int tot_days = (dateTimePicker2.Value - dateTimePicker1.Value).Days;
            int days = tot_days;

            if (tot_days < 0 | dateTimePicker1.Value <= DateTime.Now )
                MessageBox.Show("Invalid selection.");

            else
            {

                if (days >= 30)
                {
                    while (days >= 30)
                    {
                        if (days % 30 == 0)
                        {
                            months = days / 30;
                            days = 0;
                        }
                        else

                        {
                            decimal d1 = (days / 30);
                            decimal a = Math.Floor(d1);
                            months = Convert.ToInt32(a);

                            days = days - (months * 30);
                        }
                    }
                }

                if (days >= 7)

                {
                    while (days >= 7)
                    {
                        if (days % 7 == 0)
                        {
                            weeks = days / 7;
                            days = 0;

                        }
                        else

                        {
                            decimal d2 = (days / 7);
                            decimal b = Math.Floor(d2);
                            weeks = Convert.ToInt32(b);

                            days = days - (weeks * 7);
                        }
                    }
                }

                label3.Text = days.ToString();
                label4.Text = weeks.ToString();
                label5.Text = months.ToString();
                label15.Text = tot_days.ToString();

                string type_id = "";

                if (comboBox1.Text == "Sedan")

                {
                    type_id = "1";
                }

                if (comboBox1.Text == "SUV")

                {
                    type_id = "2";
                }
                if (comboBox1.Text == "Van")

                {
                    type_id = "3";
                }
                if (comboBox1.Text == "Truck")

                {
                    type_id = "4";
                }
                if (comboBox1.Text == "Luxury Sedan")

                {
                    type_id = "5";
                }
                if (comboBox1.Text == "Luxury SUV")

                {
                    type_id = "6";
                }

                decimal dayrate = 0;
                decimal weekrate = 0;
                decimal monthrate = 0;

                if (type_id != "")
                {
                    myCommand.CommandText = "select daily_rate, weekly_rate, monthly_rate from car_type where typeid = " + type_id;

                    try
                    {
                        myReader = myCommand.ExecuteReader();

                        while (myReader.Read())
                        {
                            dayrate = Convert.ToDecimal(myReader["daily_rate"]);
                            weekrate = Convert.ToDecimal(myReader["weekly_rate"]);
                            monthrate = Convert.ToDecimal(myReader["monthly_rate"]);
                        }

                        myReader.Close();
                    }
                    catch (Exception e3)
                    {
                        MessageBox.Show(e3.ToString(), "Error");
                    }

                    decimal temp = dayrate * days + weekrate * weeks + monthrate * months;
                    decimal temp2 = Math.Round(temp, 2); 
                    label10.Text = "$ " + temp2.ToString();

                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void Pickups_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int months = 0;
            int weeks = 0;

            int tot_days = (dateTimePicker2.Value - dateTimePicker1.Value).Days;
            int days = tot_days;

            if (tot_days < 0 | dateTimePicker1.Value < DateTime.Now)
                MessageBox.Show("Invalid selection.");

            else
            {

                if (days >= 30)
                {
                    while (days >= 30)
                    {
                        if (days % 30 == 0)
                        {
                            months = days / 30;
                            days = 0;
                        }
                        else

                        {
                            decimal d1 = (days / 30);
                            decimal a = Math.Floor(d1);
                            months = Convert.ToInt32(a);

                            days = days - (months * 30);
                        }
                    }
                }

                if (days >= 7)

                {
                    while (days >= 7)
                    {
                        if (days % 7 == 0)
                        {
                            weeks = days / 7;
                            days = 0;

                        }
                        else

                        {
                            decimal d2 = (days / 7);
                            decimal b = Math.Floor(d2);
                            weeks = Convert.ToInt32(b);

                            days = days - (weeks * 7);
                        }
                    }
                }

                label3.Text = days.ToString();
                label4.Text = weeks.ToString();
                label5.Text = months.ToString();
                label15.Text = tot_days.ToString();

                string type_id = "";

                if (comboBox2.Text == "Sedan")

                {
                    type_id = "1";
                }

                if (comboBox2.Text == "SUV")

                {
                    type_id = "2";
                }
                if (comboBox2.Text == "Van")

                {
                    type_id = "3";
                }
                if (comboBox2.Text == "Truck")

                {
                    type_id = "4";
                }
                if (comboBox2.Text == "Luxury Sedan")

                {
                    type_id = "5";
                }
                if (comboBox2.Text == "Luxury SUV")

                {
                    type_id = "6";
                }

                decimal dayrate = 0;
                decimal weekrate = 0;
                decimal monthrate = 0;

                if (type_id != "")
                {
                    myCommand.CommandText = "select daily_rate, weekly_rate, monthly_rate from car_type where typeid = " + type_id;

                    try
                    {
                        myReader = myCommand.ExecuteReader();

                        while (myReader.Read())
                        {
                            dayrate = Convert.ToDecimal(myReader["daily_rate"]);
                            weekrate = Convert.ToDecimal(myReader["weekly_rate"]);
                            monthrate = Convert.ToDecimal(myReader["monthly_rate"]);
                        }

                        myReader.Close();
                    }
                    catch (Exception e3)
                    {
                        MessageBox.Show(e3.ToString(), "Error");
                    }

                    decimal temp = dayrate * days + weekrate * weeks + monthrate * months;
                    decimal temp2 = Math.Round(temp, 2);
                    label10.Text = "$ " + temp2.ToString();
                }
            }
        }
    }
}
