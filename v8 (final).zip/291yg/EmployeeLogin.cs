﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _291yg
{
    public partial class EmployeeLogin : Form
    {
        public String eID;
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            eID = comboBox1.Text;

            if (eID != "" & textBox1.Text == "1")
            {
                RentalEmployee RE = new RentalEmployee(eID);
                RE.Show();
                this.Hide();
            }
            else
            { MessageBox.Show("Access Denied"); }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login L2 = new Login();
            L2.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
