﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _291yg
{
    public partial class Customer_Picker : Form
    {
        public SqlConnection myConnection;
        public SqlCommand myCommand;
        public SqlDataReader myReader;

        public String CID;
        public String EID;
        public Customer_Picker(String A)
        {
            InitializeComponent();

            EID = A;

            String connectionString = "Server = DESKTOP-A7CNV87; Database = projects22g6; Trusted_Connection = yes;";

            SqlConnection myConnection = new SqlConnection(connectionString); // Timeout in seconds

            try
            {
                myConnection.Open(); // Open connection
                myCommand = new SqlCommand();
                myCommand.Connection = myConnection; // Link the command stream to the connection
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error");
                this.Close();
            }

            myCommand.CommandText = "select customer_ID from customer";

            try
            {
                myReader = myCommand.ExecuteReader();

                comboBox1.Items.Clear();
                while (myReader.Read())
                {
                    comboBox1.Items.Add(myReader["customer_id"].ToString());
                }

                myReader.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Error");
                this.Close();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
              CID = comboBox1.Text;
              Pickups P2 = new Pickups(CID, EID);
              P2.Show();
              this.Hide();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
