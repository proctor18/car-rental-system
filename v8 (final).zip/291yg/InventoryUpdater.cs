﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _291yg
{
    public partial class Inventory_Updater : Form
    {

        public SqlConnection myConnection;
        public SqlCommand myCommand;
        public SqlDataReader myReader;

        public Inventory_Updater()
        {
            InitializeComponent();
            String connectionString = "Server = DESKTOP-A7CNV87; Database = projects22g6; Trusted_Connection = yes;";

            SqlConnection myConnection = new SqlConnection(connectionString); // Timeout in seconds

            try
            {
                myConnection.Open(); // Open connection
                myCommand = new SqlCommand();
                myCommand.Connection = myConnection; // Link the command stream to the connection
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error");
                this.Close();
            }



            try
            {
                myCommand.CommandText = "select car_id from car C";
                myReader = myCommand.ExecuteReader();

                comboBox2.Items.Clear();
                while (myReader.Read())
                {
                    comboBox2.Items.Add(myReader["car_id"].ToString());
                }

                myReader.Close();
            }
            catch (Exception e3)
            {
                MessageBox.Show(e3.ToString(), "Error");
            }

            label1.Visible = false;
            comboBox2.Visible = false;
            button3.Visible = false;

            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;

            label2.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox3.Text == "North Alberta")
            {
                myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'North Alberta'";

                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }

            else if (comboBox3.Text == "South Alberta")
            {
                myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'South Alberta'";

              
                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }

            else if (comboBox3.Text == "West BC")
            {
                myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid and B.bName = 'West BC'";

                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }

            else
            {
                myCommand.CommandText = "select * from car C, branch B, car_type T where C.branchID = B.branchID and C.typeid = T.typeid";

                /*if (operation.Text == "Show with starting grade: ")
                    myCommand.CommandText += " where grade >= " + SmallestGrade.Text;*/

                try
                {
                    MessageBox.Show(myCommand.CommandText);
                    myReader = myCommand.ExecuteReader();

                    carinv.Rows.Clear();
                    while (myReader.Read())
                    {
                        carinv.Rows.Add(myReader["car_id"].ToString(), myReader["model"].ToString(), myReader["mileage"].ToString(), myReader["typename"].ToString(), myReader["bName"].ToString(), myReader["daily_rate"].ToString(), myReader["weekly_rate"].ToString(), myReader["monthly_rate"].ToString());
                    }

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    MessageBox.Show(e3.ToString(), "Error");
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Edit")
            {
                label1.Visible = true;
                comboBox2.Visible = true;
                button3.Visible = true;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = false;

                label2.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = false;
                label9.Visible = true;
                label10.Visible = true;
            }
            else if (comboBox1.Text == "Add")
            {
                label1.Visible = false;
                comboBox2.Visible = false;
                button3.Visible=false;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;

                label2.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;

                textBox1.Text = null;
                textBox2.Text = null;
                textBox3.Text = null;
                textBox4.Text = null;
                textBox5.Text = null;
            }
            else if (comboBox1.Text == "Remove")
            {
                label1.Visible = true;
                comboBox2.Visible = true;
                button3.Visible = false;   

                textBox1.Visible = false;
                textBox2.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
                textBox6.Visible= false;

                label2.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
                label8.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Edit")
            {
                try
                {
                    myCommand.CommandText = "select * from car C, car_type T, branch B where B.branchID = C.branchID and C.typeid = T.typeid and car_id = " + comboBox2.Text.ToString();
                    myReader = myCommand.ExecuteReader();

                    myReader.Read();

                    textBox1.Text = myReader["plate"].ToString();
                    textBox2.Text = myReader["model"].ToString();
                    textBox3.Text = myReader["mileage"].ToString();
                    textBox4.Text = myReader["typeid"].ToString();
                    textBox5.Text = myReader["branchID"].ToString();
                    label9.Text = myReader["typename"].ToString();
                    label10.Text = myReader["bName"].ToString();

                    myReader.Close();
                }
                catch (Exception e3)
                {
                    myReader.Close();
                    MessageBox.Show(e3.ToString(), "Error");
                }

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
       

        }

        private void label9_Click(object sender, EventArgs e)
        {
            try
            {
                myCommand.CommandText = "select * from car C, car_type T where C.typeid = T.typeid and C.typeid = " + textBox4.Text.ToString();
                myReader = myCommand.ExecuteReader();

                myReader.Read();

                label9.Text = myReader["typename"].ToString();


                myReader.Close();
            }
            catch (Exception e3)
            {
                myReader.Close();
                label9.Text = "n/a";
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            try
            {
                myCommand.CommandText = "select * from car C, branch B where C.branchID = B.branchID and B.branchID = " + textBox5.Text.ToString();
                myReader = myCommand.ExecuteReader();

                myReader.Read();

                label10.Text = myReader["bName"].ToString();


                myReader.Close();
            }
            catch (Exception e3)
            {
                myReader.Close();
                label10.Text = "n/a";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {

                if (comboBox1.Text == "Add")
                {
                    try
                    {
                        myCommand.CommandText = "insert into car values (" + textBox6.Text + ", '" + textBox1.Text + "', '" + textBox2.Text + "', " + textBox3.Text + "," + textBox4.Text + ", " + textBox5.Text + ")";
                        MessageBox.Show(myCommand.CommandText);
                        myCommand.ExecuteNonQuery();
                    }

                    catch (Exception e4)
                    {
                        MessageBox.Show(e4.ToString(), "Error");
                    }

                    try
                    {
                        myCommand.CommandText = "select car_id from car C";
                        myReader = myCommand.ExecuteReader();

                        comboBox2.Items.Clear();
                        while (myReader.Read())
                        {
                            comboBox2.Items.Add(myReader["car_id"].ToString());
                        }

                        myReader.Close();
                    }
                    catch (Exception e3)
                    {
                        MessageBox.Show(e3.ToString(), "Error");
                    }
                }

                else if (comboBox1.Text == "Edit")
                {
                    try
                    {
                        myCommand.CommandText = "delete from car where car_id = " + comboBox2.Text;
                        MessageBox.Show(myCommand.CommandText);
                        myCommand.ExecuteNonQuery();

                        myCommand.CommandText = "insert into car values (" + comboBox2.Text + ", '" + textBox1.Text + "', '" + textBox2.Text + "', " + textBox3.Text + "," + textBox4.Text + ", " + textBox5.Text + ")";
                        MessageBox.Show(myCommand.CommandText);
                        myCommand.ExecuteNonQuery();
                    }


                    catch (Exception e4)
                    {
                        MessageBox.Show(e4.ToString(), "Error");
                    }

                    try
                    {
                        myCommand.CommandText = "select car_id from car C";
                        myReader = myCommand.ExecuteReader();

                        comboBox2.Items.Clear();
                        while (myReader.Read())
                        {
                            comboBox2.Items.Add(myReader["car_id"].ToString());
                        }

                        myReader.Close();
                    }
                    catch (Exception e3)
                    {
                        MessageBox.Show(e3.ToString(), "Error");
                    }
                }
                else if (comboBox1.Text == "Remove")
                {
                    try
                    {
                        myCommand.CommandText = "delete from car where car_id = " + comboBox2.Text;
                        MessageBox.Show(myCommand.CommandText);
                        myCommand.ExecuteNonQuery();

                    }

                    catch (Exception e4)
                    {
                        MessageBox.Show(e4.ToString(), "Error");
                    }

                    try
                    {
                        myCommand.CommandText = "select car_id from car C";
                        myReader = myCommand.ExecuteReader();

                        comboBox2.Items.Clear();
                        while (myReader.Read())
                        {
                            comboBox2.Items.Add(myReader["car_id"].ToString());
                        }

                        myReader.Close();
                    }
                    catch (Exception e3)
                    {
                        MessageBox.Show(e3.ToString(), "Error");
                    }

                }

            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
