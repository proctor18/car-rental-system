﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _291yg
{
    public partial class Custom : Form
    {
        public SqlConnection myConnection;
        public SqlCommand myCommand;
        public SqlDataReader myReader;
        public Custom()
        {
            InitializeComponent();
            String connectionString = "Server = DESKTOP-A7CNV87; Database = projects22g6; Trusted_Connection = yes;";

            SqlConnection myConnection = new SqlConnection(connectionString); // Timeout in seconds

            try
            {
                myConnection.Open(); // Open connection
                myCommand = new SqlCommand();
                myCommand.Connection = myConnection; // Link the command stream to the connection
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error");
                this.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                myCommand.CommandText = "select top "+textBox1.Text+ " typename from branch, car, car_type where car.branchID = branch.branchID and car.typeid = car_type.typeid and car.branchID = " + textBox2.Text+" group by car_type.typename";
                myReader = myCommand.ExecuteReader();
                string a1 = "";
                while (myReader.Read())
                {
                    a1 += myReader["typename"].ToString() + ", ";
                }
                MessageBox.Show(a1);
                myReader.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Error");
                this.Close();

            }
        
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                myCommand.CommandText = "select top 1 typename from [transaction], car_type where car_type.typeid = [transaction].requested_type and pickup_location = "+ textBox3.Text+" group by typename";
                myReader = myCommand.ExecuteReader();
                string a1 = "";
                while (myReader.Read())
                {
                    a1 += myReader["typename"].ToString();
                }
                MessageBox.Show(a1);
                myReader.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Error");
                this.Close();

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                myCommand.CommandText = "select top 1 bName from branch, [transaction] where branch.branchID = [transaction].pickup_location and province = '"+ textBox4.Text+"' group by bName";
                myReader = myCommand.ExecuteReader();
                string a1 = "";
                while (myReader.Read())
                {
                    a1 += myReader["bName"].ToString();
                }
                MessageBox.Show(a1);
                myReader.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Error");
                this.Close();

            }

        }
    }
}
