﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _291yg
{
    public partial class RentalEmployee : Form
    {
        public String eID;
        public RentalEmployee(String A)
        {
            InitializeComponent();
            eID = A;
            label1.Text = eID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Inventory")
            {
                Inventory_Updater IU = new Inventory_Updater();
                IU.Show();

            }
            else if (comboBox1.Text == "Customers")
            {
                Customers Cu = new Customers();
                Cu.Show();
            }
            else if (comboBox1.Text == "Pickups")
            {
                Customer_Picker C1 = new Customer_Picker(eID);
                C1.Show();

            }
            else if (comboBox1.Text == "Returns")
            {
                return_Transaction RT = new return_Transaction();
                RT.Show();

            }
            else if (comboBox1.Text == "Exec")
            {
                Custom ct = new Custom();


              ct.Show();
            }
            else
            {
                MessageBox.Show("Select from the combo box");
                    }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void RentalEmployee_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
