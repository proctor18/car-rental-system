﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _291yg
{
    public partial class return_transaction2 : Form
    {
        public SqlConnection myConnection;
        public SqlCommand myCommand;
        public SqlDataReader myReader;

        public string cID;
        public int total;
        public return_transaction2(string I)
        {
            InitializeComponent();
            cID = I;
            label2.Text = cID;

            String connectionString = "Server = DESKTOP-A7CNV87; Database = projects22g6; Trusted_Connection = yes;";

            SqlConnection myConnection = new SqlConnection(connectionString); // Timeout in seconds

            try
            {
                myConnection.Open(); // Open connection
                myCommand = new SqlCommand();
                myCommand.Connection = myConnection; // Link the command stream to the connection
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error");
                this.Close();
            }
            
            
            try
            {

                myCommand.CommandText = $"select * from [transaction] where requested_by = " + cID;
                myReader = myCommand.ExecuteReader();

                dataGridView1.Rows.Clear();
                while (myReader.Read())
                {
                    dataGridView1.Rows.Add(myReader["transaction_ID"].ToString(), myReader["requested_type"].ToString(), myReader["total_cost"].ToString(), myReader["start_date"].ToString(), myReader["promised_date"].ToString());
                }

                myReader.Close();
            }

            catch (Exception e3)
            {
                MessageBox.Show(e3.ToString(), "Error");
            }
            
        
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            if (textBox1 != null) { total = Int32.Parse(textBox1.Text); }
            if (checkBox1.Checked) { total = total + 100; }
            if (checkBox2.Checked & !checkBox3.Checked) { total = total + 100; }
            label5.Text = total.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            myCommand.CommandText = "UPDATE [transaction] SET return_location = '" + textBox2.Text + "' where transaction_ID = '" + textBox2.Text + "'";
            MessageBox.Show(myCommand.CommandText);
            myCommand.ExecuteNonQuery();

            /* myCommand.CommandText = "UPDATE car SET branchID = '" + textBox2.Text + "' where car_ID = '" + textBox2.Text + "'";
            MessageBox.Show(myCommand.CommandText);
            myCommand.ExecuteNonQuery();

            /// THERE IS NO CAR_ID IN THE TRANSACTION TABLE SO WE CANNOT UPDATE THE SPECIFIC CAR'S LOCATION */

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
